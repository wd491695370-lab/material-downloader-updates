# material-downloader-updates

Public update channel for 素材下载助手.

Only `version.json` and `material-downloader-latest.apk` are published here. Do not store source code, cookies, account data, or secrets in this repository.
